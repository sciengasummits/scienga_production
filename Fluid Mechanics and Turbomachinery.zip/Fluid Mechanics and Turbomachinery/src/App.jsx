import React from 'react';
import { BrowserRouter } from 'react-router-dom';
import AppRoutes from './routes/AppRoutes';
import './assets/styles/global.css';

import Home from './pages/Home/Home';

function App() {
  return (
    <BrowserRouter>
      <div style={{ background: 'white', color: 'black' }}>
        <h1>APP COMPONENT MOUNTED</h1>
        <Home />
      </div>
    </BrowserRouter>
  );
}

export default App;
