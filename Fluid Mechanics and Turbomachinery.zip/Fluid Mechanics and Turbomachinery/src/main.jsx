// import React from 'react'
// import ReactDOM from 'react-dom/client'
// import App from './App.jsx'
// import './index.css'

const log = (msg) => {
  const el = document.getElementById('debug-log');
  if (el) el.innerHTML += 'JS: ' + msg + '<br/>';
  console.log(msg);
};

log('MAIN.JSX EXECUTING (NO IMPORTS)');
document.getElementById('root').innerHTML = '<h1 style="color: green">PLAIN JS WORKING IN MAIN.JSX</h1>';
